path = ('/home/max/Bilder/BilderProbe9');
liste=dir(path);
files={liste(~[liste.isdir]).name};
h=length(files);
for a = 1:h
    
    bild{a} = imread( fullfile(path,files{a}));
    
    bildzugeschnitten = imcrop(bild{a},[16.4999999999998 539 2559 789]);
    bildzugeschnitten1{a} = bildzugeschnitten;
    bildgrau{a} = rgb2gray(bildzugeschnitten1{a});
end
for a = 1:(h)
    subplot(2,3,a)
       
    difference{a}=imabsdiff(bildgrau{a},bildgrau{h});
    invert{a}= imcomplement(difference{a});
    diffsw{a}= im2bw(invert{a},0.988);
    
    
    %imshow(diffsw{a});
    zwischenergebnis{a}= medfilt2(diffsw{a},[6 6]);
    
    hold on;
    imshow(bildzugeschnitten1{a});
    alpha{a} = imshow(zwischenergebnis{a});
    set(alpha{a},'AlphaData',0.15);
end
for a=1:h
figure;
imshow(bildzugeschnitten1{a});
hold on;

beta = imshow(zwischenergebnis{a});
set(beta,'AlphaData',0.15);

end




%bildsw{a} = im2bw(bildgrau{a},0.012)    %Level einstellen schwarz weiß